/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller_clase;

/**
 *
 * @author ROZO
 */
public class Gerente extends Directivo {
   
    private String categoria;

    public Gerente(String nombre) {
        super(nombre);
        this.categoria = "Isimo";
         setSalarioBase(1000);
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
    public void incrementarSalario() {
        setSalarioBase(getSalarioBase() * 1.2);
    }

    public String toString() {
        return super.toString() + " -> Gerente Isimo";
    }

    
    
}

    

