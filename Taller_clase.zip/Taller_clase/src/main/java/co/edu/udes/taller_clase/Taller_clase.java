/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package co.edu.udes.taller_clase;

/**
 *
 * @author ROZO
 */
public class Taller_clase {

    public static void main(String[] args) {
    // Crear instancias de empleados
    Empleado emp1 = new Empleado("Juan");
    Empleado emp2 = new Operario("Maria");
    Empleado emp3 = new Tecnico("Pedro");
    Empleado emp4 = new Supervisor("Luis");
    Empleado emp5 = new Directivo("Laura");
    Empleado emp6 = new Secretaria("Ana");
    Empleado emp7 = new Gerente("Carlos");

    // Mostrar información de empleados
    System.out.println(emp1);
    System.out.println(emp2);
    System.out.println(emp3);
    System.out.println(emp4);
    System.out.println(emp5);
    System.out.println(emp6);
    System.out.println(emp7);

 incrementarSalario(emp3, 0.2);
    incrementarSalario(emp4, 0.2);
    incrementarSalario(emp6, 0.2);
    incrementarSalario(emp7, 0.2);
    incrementarSalario(emp2, 0.4);
    incrementarSalario(emp5, 0.4);
    incrementarSalario(emp1, 0.6);

    // Mostrar información de empleados actualizada
    System.out.println("Salarios actualizados:");
    System.out.println(emp1);
    System.out.println(emp2);
    System.out.println(emp3);
    System.out.println(emp4);
    System.out.println(emp5);
    System.out.println(emp6);
    System.out.println(emp7);
}

    }

