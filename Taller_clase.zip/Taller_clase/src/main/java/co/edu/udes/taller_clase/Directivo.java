/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller_clase;

/**
 *
 * @author ROZO
 */
public class Directivo extends Empleado {
     public Directivo(String nombre) {
        super(nombre);
        setSalarioBase(1000);
    }

    public void incrementarSalario() {
        setSalarioBase(getSalarioBase() * 1.4);
    }

    public String toString() {
        return super.toString() + " -> Directivo D1";
    }
}
